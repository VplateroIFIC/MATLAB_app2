//   PartialProfile.cpp: demo-application for using the LLT.dll
//
//   Version 3.9.0
//
//   Copyright 2019
//
//   MICRO-EPSILON GmbH & Co. KG
//   K�nigbacher Str. 15
//   94496 Ortenburg
//   Germany
//---------------------------------------------------------------------------

#include "stdafx.h"
#include <iostream>
#include <conio.h>
#include "InterfaceLLT_2.h"
#include "PartialProfile.h"

using namespace std;

static CInterfaceLLT* m_pLLT = NULL;
static unsigned int m_uiResolution = 0;
static TScannerType m_tscanCONTROLType = scanCONTROL2xxx;

int main(int argc, char* argv[])
{
	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);
	vector<unsigned int> vuiInterfaces(MAX_INTERFACE_COUNT);
	vector<DWORD> vdwResolutions(MAX_RESOULUTIONS);
	unsigned int uiInterfaceCount = 0;
	unsigned int uiExposureTime = 100;
	unsigned int uiIdleTime = 3900;
	TScannerType ScannerType = scanCONTROL2xxx;
	bool bLoadError = false;
	int iRetValue = 0;
	bool bOK = true;
	bool bConnected = false;

	// Creating a LLT-object
	// The LLT-Object will load the LLT.dll automaticly and give us a error if ther no LLT.dll
	m_pLLT = new CInterfaceLLT("..\\LLT.dll", &bLoadError);

	if (bLoadError)
	{
		cout << "Error loading LLT.dll \n";

		// Wait for a keyboard hit
		while (!_kbhit()) {}

		// Deletes the LLT-object
		delete m_pLLT;
		return -1;
	}

	// Create a Device
	if (m_pLLT->CreateLLTDevice(INTF_TYPE_ETHERNET))
		cout << "CreateLLTDevice OK \n";
	else
		cout << "Error during CreateLLTDevice\n";

	// Gets the available interfaces from the scanCONTROL-device
	iRetValue = m_pLLT->GetDeviceInterfacesFast(&vuiInterfaces[0], (unsigned int)vuiInterfaces.size());

	if (iRetValue == ERROR_GETDEVINTERFACES_REQUEST_COUNT)
	{
		cout << "There are more or equal than " << vuiInterfaces.size() << " scanCONTROL connected \n";
		uiInterfaceCount = (unsigned int)vuiInterfaces.size();
	}
	else if (iRetValue < 0)
	{
		cout << "A error occured during searching for connected scanCONTROL \n";
		uiInterfaceCount = 0;
	}
	else
	{
		uiInterfaceCount = iRetValue;
	}

	if (uiInterfaceCount == 0)
		cout << "There is no scanCONTROL connected \n";
	else if (uiInterfaceCount == 1)
		cout << "There is 1 scanCONTROL connected \n";
	else
		cout << "There are " << uiInterfaceCount << " scanCONTROL's connected \n";

	if (uiInterfaceCount >= 1)
	{
		cout << "\nSelect the device interface " << vuiInterfaces[0] << "\n";
		if ((iRetValue = m_pLLT->SetDeviceInterface(vuiInterfaces[0], 0)) < GENERAL_FUNCTION_OK)
		{
			OnError("Error during SetDeviceInterface", iRetValue);
			bOK = false;
		}

		if (bOK)
		{
			cout << "Connecting to scanCONTROL\n";
			if ((iRetValue = m_pLLT->Connect()) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during Connect", iRetValue);
				bOK = false;
			}
			else
				bConnected = true;
		}

		if (bOK)
		{
			cout << "Get scanCONTROL type\n";
			if ((iRetValue = m_pLLT->GetLLTType(&m_tscanCONTROLType)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during GetLLTType", iRetValue);
				bOK = false;
			}

			if (iRetValue == GENERAL_FUNCTION_DEVICE_NAME_NOT_SUPPORTED)
			{
				cout << "Can't decode scanCONTROL type. Please contact Micro-Epsilon for a newer version of the LLT.dll.\n";
			}
			if (m_tscanCONTROLType >= scanCONTROL27xx_25 && m_tscanCONTROLType <= scanCONTROL27xx_xxx)
			{
				cout << "The scanCONTROL is a scanCONTROL27xx\n\n";
			}
			else if (m_tscanCONTROLType >= scanCONTROL25xx_25 && m_tscanCONTROLType <= scanCONTROL25xx_xxx)
			{
				cout << "The scanCONTROL is a scanCONTROL25xx\n\n";
			}
			else if (m_tscanCONTROLType >= scanCONTROL26xx_25 && m_tscanCONTROLType <= scanCONTROL26xx_xxx)
			{
				cout << "The scanCONTROL 1 is a scanCONTROL26xx\n\n";
			}
			else if (m_tscanCONTROLType >= scanCONTROL29xx_25 && m_tscanCONTROLType <= scanCONTROL29xx_xxx)
			{
				cout << "The scanCONTROL 1 is a scanCONTROL29xx\n\n";
			}
			else if (m_tscanCONTROLType >= scanCONTROL30xx_25 && m_tscanCONTROLType <= scanCONTROL30xx_xxx)
			{
				cout << "The scanCONTROL is a scanCONTROL30xx\n\n";
			}
			else
			{
				cout << "The scanCONTROL is a undefined type\nPlease contact Micro-Epsilon for a newer SDK\n\n";
			}

			cout << "Get all possible resolutions\n";
			if ((iRetValue = m_pLLT->GetResolutions(&vdwResolutions[0], (unsigned int)vdwResolutions.size())) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during GetResolutions", iRetValue);
				bOK = false;
			}

			m_uiResolution = vdwResolutions[0];
		}

		if (bOK)
		{
			cout << "Set resolution to " << m_uiResolution << "\n";
			if ((iRetValue = m_pLLT->SetResolution(m_uiResolution)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during SetResolution", iRetValue);
				bOK = false;
			}
		}

		if (bOK)
		{
			cout << "Set trigger to internal\n";
			if ((iRetValue = m_pLLT->SetFeature(FEATURE_FUNCTION_TRIGGER, TRIG_INTERNAL)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during SetFeature(FEATURE_FUNCTION_TRIGGER)", iRetValue);
				bOK = false;
			}
		}

		if (bOK)
		{
			cout << "Profile config set to PARTIAL_PROFILE\n";
			if ((iRetValue = m_pLLT->SetProfileConfig(PARTIAL_PROFILE)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during SetProfileConfig", iRetValue);
				bOK = false;
			}
		}

		if (bOK)
		{
			cout << "Set shutter time to " << uiExposureTime << "\n";
			if ((iRetValue = m_pLLT->SetFeature(FEATURE_FUNCTION_EXPOSURE_TIME, uiExposureTime)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during SetFeature(FEATURE_FUNCTION_EXPOSURE_TIME)", iRetValue);
				bOK = false;
			}
		}

		if (bOK)
		{
			cout << "Set idle time to " << uiIdleTime << "\n";
			if ((iRetValue = m_pLLT->SetFeature(FEATURE_FUNCTION_IDLE_TIME, uiIdleTime)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during SetFeature(FEATURE_FUNCTION_IDLE_TIME)", iRetValue);
				bOK = false;
			}
		}

		if (bOK)
		{
			cout << "Gets the type of the scanCONTROL (measurement range)\n";

			if ((iRetValue = m_pLLT->GetLLTType(&ScannerType)) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during GetLLTType", iRetValue);
				bOK = false;
			}
		}

		if (bOK)
		{
			bOK = PartialProfile_Pure(ScannerType);
		}
		if (bOK)
		{
			bOK = PartialProfile_Quarter(ScannerType);
			;
		}

		if (bConnected)
		{
			cout << "Disconnect the scanCONTROL\n";
			if ((iRetValue = m_pLLT->Disconnect()) < GENERAL_FUNCTION_OK)
			{
				OnError("Error during Disconnect", iRetValue);
			}
		}
	}

	// Deletes the LLT-object
	delete m_pLLT;

	// Wait for a keyboard hit
	while (!_kbhit()) {}

	return 0;
}

bool PartialProfile_Pure(TScannerType tscanCONTROLType)
{
	vector<unsigned char> vucProfileBuffer;
	TPartialProfile tPartialProfile;
	int iRetValue;

	vector<double> vdValueX(m_uiResolution);
	vector<double> vdValueZ(m_uiResolution);

	// Struct for a partial transfer with the half resolution and only the X- and Z-values (like PURE_PROFILE)
	tPartialProfile.nStartPoint = 20;                 // Transfer starts at point 20 (as row)
	tPartialProfile.nStartPointData = 4;              // Transfer starts at data position 4 (as column)
	tPartialProfile.nPointCount = m_uiResolution / 2; // Transfer size are the half of the resolution (the half of the points)
	tPartialProfile.nPointDataWidth = 4;              // Transfer size of the transfered data is 4

	// Resize the profile buffer to the maximal profile size
	vucProfileBuffer.resize(tPartialProfile.nPointCount * tPartialProfile.nPointDataWidth);

	cout << "\nTransfers a profile with the half resolution and only the X- and Z-values (like PURE_PROFILE)";
	cout << "\nPartialProfile set to " << tPartialProfile.nStartPoint << ", " << tPartialProfile.nStartPointData;
	cout << ", " << tPartialProfile.nPointCount << ", " << tPartialProfile.nPointDataWidth << "\n";

	if ((iRetValue = m_pLLT->SetPartialProfile(&tPartialProfile)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during SetPartialProfile", iRetValue);
		return false;
	}

	cout << "Enable the measurement\n";
	if ((iRetValue = m_pLLT->TransferProfiles(NORMAL_TRANSFER, true)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during TransferProfiles", iRetValue);
		return false;
	}

	// Sleep for a while to warm up the transfer
	Sleep(500);

	cout << "Gets a profile in polling-mode with PARTIAL_PROFILE\n\n";
	if ((iRetValue = m_pLLT->GetActualProfile(&vucProfileBuffer[0], (unsigned int)vucProfileBuffer.size(), PARTIAL_PROFILE, NULL)) !=
		(int)vucProfileBuffer.size())
	{
		OnError("Error wrong profilesize", iRetValue);
		return false;
	}

	cout << "Get profile in polling-mode and PARTIAL_PROFILE configuration OK \n";

	cout << "Converting of profile data from the first reflection\n";
	if ((iRetValue = m_pLLT->ConvertPartProfile2Values(&vucProfileBuffer[0], &tPartialProfile, tscanCONTROLType, 0, true, NULL, NULL,
		NULL, &vdValueX[0], &vdValueZ[0], NULL, NULL)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during Converting of profile data", iRetValue);
		return false;
	}

	// Display the profile (note the last 16 byte of the partial profile are the timastamp
	// -> we lose four point)
	DisplayProfile(&vdValueX[0], &vdValueZ[0], tPartialProfile.nPointCount - 4);

	cout << "\n\nDisplay the timestamp from the profile:";
	DisplayTimestamp(&vucProfileBuffer[tPartialProfile.nPointCount * tPartialProfile.nPointDataWidth - 16]);

	cout << "Disable the measurement\n";
	if ((iRetValue = m_pLLT->TransferProfiles(NORMAL_TRANSFER, false)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during TransferProfiles", iRetValue);
		return false;
	}
	return true;
}

bool PartialProfile_Quarter(TScannerType tscanCONTROLType)
{
	vector<unsigned char> vucProfileBuffer;
	TPartialProfile tPartialProfile;
	int iRetValue;

	vector<double> vdValueX(m_uiResolution);
	vector<double> vdValueZ(m_uiResolution);

	// Struct for a partial transfer with the full resolution and only one reflection (like QUARTER_PROFILE)
	tPartialProfile.nStartPoint = 0;              // Transfer starts at point 0 (as row)
	tPartialProfile.nStartPointData = 0;          // Transfer starts at data position 0 (as column)
	tPartialProfile.nPointCount = m_uiResolution; // Transfer size are the full resolution
	tPartialProfile.nPointDataWidth = 16;         // Transfer size of the transfered data is 16

	// Resize the profile buffer to the maximal profile size
	vucProfileBuffer.resize(tPartialProfile.nPointCount * tPartialProfile.nPointDataWidth);

	cout << "\nTransfers a profile with the full resolution and only one reflection (like QUARTER_PROFILE)";
	cout << "\nPartialProfile set to " << tPartialProfile.nStartPoint << ", " << tPartialProfile.nStartPointData;
	cout << ", " << tPartialProfile.nPointCount << ", " << tPartialProfile.nPointDataWidth << "\n";

	if ((iRetValue = m_pLLT->SetPartialProfile(&tPartialProfile)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during SetPartialProfile", iRetValue);
		return false;
	}

	cout << "Enable the measurement\n";
	if ((iRetValue = m_pLLT->TransferProfiles(NORMAL_TRANSFER, true)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during TransferProfiles", iRetValue);
		return false;
	}

	// Sleep for a while to warm up the transfer
	Sleep(500);

	cout << "Gets a profile in polling-mode with PARTIAL_PROFILE\n\n";
	if ((iRetValue = m_pLLT->GetActualProfile(&vucProfileBuffer[0], (unsigned int)vucProfileBuffer.size(), PARTIAL_PROFILE, NULL)) !=
		(int)vucProfileBuffer.size())
	{
		OnError("Error wrong profilesize", iRetValue);
		return false;
	}

	cout << "Get profile in polling-mode and PARTIAL_PROFILE configuration OK \n";

	cout << "Converting of profile data from the first reflection\n";
	if ((iRetValue = m_pLLT->ConvertPartProfile2Values(&vucProfileBuffer[0], &tPartialProfile, tscanCONTROLType, 0, true, NULL, NULL,
		NULL, &vdValueX[0], &vdValueZ[0], NULL, NULL)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during Converting of profile data", iRetValue);
		return false;
	}

	// Display the profile (note the last 16 byte of the partial profile are the timastamp
	// -> we lose one point)
	DisplayProfile(&vdValueX[0], &vdValueZ[0], tPartialProfile.nPointCount - 1);

	cout << "\n\nDisplay the timestamp from the profile:";
	DisplayTimestamp(&vucProfileBuffer[tPartialProfile.nPointCount * tPartialProfile.nPointDataWidth - 16]);

	cout << "Disable the measurement\n";
	if ((iRetValue = m_pLLT->TransferProfiles(NORMAL_TRANSFER, false)) < GENERAL_FUNCTION_OK)
	{
		OnError("Error during TransferProfiles", iRetValue);
		return false;
	}
	return true;
}

// Displaying the error text
void OnError(const char* szErrorTxt, int iErrorValue)
{
	char acErrorString[200];

	cout << szErrorTxt << "\n";
	if (m_pLLT->TranslateErrorValue(iErrorValue, acErrorString, sizeof(acErrorString)) >= GENERAL_FUNCTION_OK)
		cout << acErrorString << "\n\n";
}

// Displays one profile
void DisplayProfile(double* pdValueX, double* pdValueZ, unsigned int uiResolution)
{
	size_t tNumberSize;

	for (unsigned int i = 0; i < uiResolution; i++)
	{
		// Prints the X- and Z-values
		tNumberSize = Double2Str(*pdValueX).size();
		cout << "\r"
			<< "Profiledata: X = " << *pdValueX++;
		for (; tNumberSize < 8; tNumberSize++)
		{
			cout << " ";
		}

		tNumberSize = Double2Str(*pdValueZ).size();
		cout << " Z = " << *pdValueZ++;
		for (; tNumberSize < 8; tNumberSize++)
		{
			cout << " ";
		}

		// Somtimes wait a short time (only for display)
		if (i % 8 == 0)
		{
			Sleep(10);
		}
	}
}

// Displays the timestamp
void DisplayTimestamp(unsigned char* pucTimestamp)
{
	double dShutterOpen, dShutterClose;
	unsigned int uiProfileCount;

	// Decode the timestamp
	m_pLLT->Timestamp2TimeAndCount(pucTimestamp, &dShutterOpen, &dShutterClose, &uiProfileCount);
	cout << "\nShutterOpen: " << dShutterOpen << " ShutterClose: " << dShutterClose << "\n";
	cout << "ProfileCount: " << uiProfileCount << "\n";
	cout << "\n";
}

// Convert a double value to a string
std::string Double2Str(double dValue)
{
	std::ostringstream NewStreamApp;
	NewStreamApp << dValue;

	return NewStreamApp.str();
}
