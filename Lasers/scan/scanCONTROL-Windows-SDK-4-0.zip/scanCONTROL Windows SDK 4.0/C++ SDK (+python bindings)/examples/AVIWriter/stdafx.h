// stdafx.h : Includedatei f�r Standardsystem-Includedateien,
// oder h�ufig verwendete, projektspezifische Includedateien,
// die nur in unregelm��igen Abst�nden ge�ndert werden.

#include <vector>
#include <string>
#include <list>
#include <map>
#include <deque>
#include <sstream>
#include <fstream>
#include <ostream>
#include <istream>
#include <iomanip>
#include <algorithm>
