//   VideoMode.h: demo-application for using the LLT.dll
//
//   Version 3.9.0
//
//   Copyright 2019
//
//   MICRO-EPSILON GmbH & Co. KG
//   K�nigbacher Str. 15
//   94496 Ortenburg
//   Germany
//---------------------------------------------------------------------------

#ifndef LLTVideoModeH
#define LLTVideoModeH

#define MAX_INTERFACE_COUNT    5

void VideoMode();
void OnError(const char* szErrorTxt, int iErrorValue);

#endif