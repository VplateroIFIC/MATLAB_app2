//   ContainerMode.h: demo-application for using the LLT.dll
//
//   Version 3.9.0
//
//   Copyright 2019
//
//   MICRO-EPSILON GmbH & Co. KG
//   K�nigbacher Str. 15
//   94496 Ortenburg
//   Germany
//---------------------------------------------------------------------------

#ifndef LLTContainerModeH
#define LLTContainerModeH

#define MAX_INTERFACE_COUNT    5
#define MAX_RESOULUTIONS       6

bool ConvertToString(char *name, int size);
void TriggerContainer();
int GetScalingAndOffsetByType(TScannerType scanner_type, double *scaling, double *offset);
void OnError(const char* szErrorTxt, int iErrorValue);


#endif
