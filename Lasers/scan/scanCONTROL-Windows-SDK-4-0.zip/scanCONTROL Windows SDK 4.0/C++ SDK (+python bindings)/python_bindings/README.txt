----------------------------------------------------------------------------------------------
For installation:
----------------------------------------------------------------------------------------------

1. Copy the correct version of the LLT.dll in the pyllt folder.

	The LLT.dll is located in the C_C++ / C# folder and must correspond architecture-wise
	with the  Python installation of the PC (32- or 64-bit version).
	If the LLT.dll is not part of the download contact: info@micro-epsilon.de


2. Copy the pyllt folder to the "site-packages" or "dist-packages" folder of your Python installation.

3. To run jupyter documentation you have to install jupyter first with "pip install jupyter"