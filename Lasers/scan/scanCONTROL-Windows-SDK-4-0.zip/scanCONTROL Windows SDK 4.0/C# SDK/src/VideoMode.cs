/*
 * scanCONTROL C# SDK - C# wrapper for LLT.dll
 *
 * MIT License
 *
 * Copyright � 2017-2018 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

using System;
using System.Text;

namespace MEScanControl
{
  class CScanCONTROLSample
  {
    /* Global variables */
    public const int MAX_INTERFACE_COUNT        = 5;
    public const int MAX_RESOULUTIONS           = 6;

    static public uint uiResolution = 0;
    static public uint hLLT = 0;
    static public CLLTI.TScannerType tscanCONTROLType;

    [STAThread]
    static void Main(string[] args)
    {
      scanCONTROL_Sample();
    }

    static void scanCONTROL_Sample()
    {
      uint[] auiInterfaces = new uint[MAX_INTERFACE_COUNT];
      uint[] auiResolutions = new uint[MAX_RESOULUTIONS];

      StringBuilder sbDevName = new StringBuilder(100);
      StringBuilder sbVenName = new StringBuilder(100);

      uint uiBufferCount = 5, uiMainReflection = 0, uiPacketSize = 1024;

      int iInterfaceCount = 0;
      uint uiExposureTime = 100;
      uint uiIdleTime = 3900;
      int iRetValue;
      bool bOK = true;
      bool bConnected = false;
      ConsoleKeyInfo cki;

      hLLT = 0;
      uiResolution = 0;

      Console.WriteLine("----- Connect to scanCONTROL -----\n");

      // Create a Ethernet Device -> returns handle to LLT device
      hLLT = CLLTI.CreateLLTDevice(CLLTI.TInterfaceType.INTF_TYPE_ETHERNET);
      if (hLLT != 0)
          Console.WriteLine("CreateLLTDevice OK");
      else
          Console.WriteLine("Error during CreateLLTDevice\n");

      // Get the available interfaces from the scanCONTROL-device    
      iInterfaceCount = CLLTI.GetDeviceInterfacesFast(hLLT, auiInterfaces, auiInterfaces.GetLength(0));
       if (iInterfaceCount <= 0)
           Console.WriteLine("FAST: There is no scanCONTROL connected");
       else if (iInterfaceCount == 1)
           Console.WriteLine("FAST: There is 1 scanCONTROL connected ");
       else
           Console.WriteLine("FAST: There are " + iInterfaceCount + " scanCONTROL's connected");

      if(iInterfaceCount >= 1)
      {
        uint target4 = auiInterfaces[0] & 0x000000FF;
        uint target3 = (auiInterfaces[0] & 0x0000FF00) >> 8;
        uint target2 = (auiInterfaces[0] & 0x00FF0000) >> 16;
        uint target1 = (auiInterfaces[0] & 0xFF000000) >> 24;

        // Set the first IP address detected by GetDeviceInterfacesFast to handle
        Console.WriteLine("Select the device interface: " + target1 + "." + target2 + "." + target3 + "." + target4);
        if((iRetValue = CLLTI.SetDeviceInterface(hLLT, auiInterfaces[0], 0)) < CLLTI.GENERAL_FUNCTION_OK)
        {
          OnError("Error during SetDeviceInterface", iRetValue);
          bOK = false;
        }

        if (bOK)
        {
            // Connect to sensor with the device interface set before
            Console.WriteLine("Connecting to scanCONTROL");
            if ((iRetValue = CLLTI.Connect(hLLT)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during Connect", iRetValue);
                bOK = false;
            }
            else
                bConnected = true;
        }   

        if (bOK)
        {
            Console.WriteLine("\n----- Get scanCONTROL Info -----\n");

            // Read the device name and vendor from scanner
            Console.WriteLine("Get Device Name");
            if ((iRetValue = CLLTI.GetDeviceName(hLLT, sbDevName, sbDevName.Capacity, sbVenName, sbVenName.Capacity)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during GetDevName", iRetValue);
                bOK = false;
            }
            else
            {
                Console.WriteLine(" - Devname: " + sbDevName + "\n - Venname: " + sbVenName);
            }
        }
        
        if(bOK)
        {
          // Get the scanCONTROL type and check if it is valid
          Console.WriteLine("Get scanCONTROL type");
          if((iRetValue = CLLTI.GetLLTType(hLLT, ref tscanCONTROLType)) < CLLTI.GENERAL_FUNCTION_OK)
          {
            OnError("Error during GetLLTType", iRetValue);
            bOK = false;
          }
    
          if(iRetValue == CLLTI.GENERAL_FUNCTION_DEVICE_NAME_NOT_SUPPORTED)
          {
            Console.WriteLine(" - Can't decode scanCONTROL type. Please contact Micro-Epsilon for a newer version of the LLT.dll.");
          }

          if(tscanCONTROLType >= CLLTI.TScannerType.scanCONTROL27xx_25 && tscanCONTROLType <= CLLTI.TScannerType.scanCONTROL27xx_xxx)
          {
              Console.WriteLine(" - The scanCONTROL is a scanCONTROL27xx");
          }
          else if (tscanCONTROLType >= CLLTI.TScannerType.scanCONTROL25xx_25 && tscanCONTROLType <= CLLTI.TScannerType.scanCONTROL25xx_xxx)
          {
              Console.WriteLine(" - The scanCONTROL is a scanCONTROL25xx");
          }
          else if (tscanCONTROLType >= CLLTI.TScannerType.scanCONTROL26xx_25 && tscanCONTROLType <= CLLTI.TScannerType.scanCONTROL26xx_xxx)
          {
              Console.WriteLine(" - The scanCONTROL is a scanCONTROL26xx");
          }
          else if (tscanCONTROLType >= CLLTI.TScannerType.scanCONTROL29xx_25 && tscanCONTROLType <= CLLTI.TScannerType.scanCONTROL29xx_xxx)
          {
              Console.WriteLine(" - The scanCONTROL is a scanCONTROL29xx");
          }
          else if (tscanCONTROLType >= CLLTI.TScannerType.scanCONTROL30xx_25 && tscanCONTROLType <= CLLTI.TScannerType.scanCONTROL30xx_xxx)
          {
              Console.WriteLine(" - The scanCONTROL is a scanCONTROL30xx");
          }
          else
          {
              Console.WriteLine(" - The scanCONTROL is a undefined type\nPlease contact Micro-Epsilon for a newer SDK");
          }

          // Get all possible resolutions for connected sensor and save them in array 
          Console.WriteLine("Get all possible resolutions");
          if ((iRetValue = CLLTI.GetResolutions(hLLT, auiResolutions, auiResolutions.GetLength(0))) < CLLTI.GENERAL_FUNCTION_OK)
          {
              OnError("Error during GetResolutions", iRetValue);
              bOK = false;
          }

          // Set the max. possible resolution
          uiResolution = auiResolutions[0];
        }

        // Set scanner settings to valid parameters for this example
        Console.WriteLine("\n----- Set scanCONTROL Parameters -----\n");

        if (bOK)
        {
            Console.WriteLine("Set resolution to " + uiResolution);
            if ((iRetValue = CLLTI.SetResolution(hLLT, uiResolution)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetResolution", iRetValue);
                bOK = false;
            }
        }

        if (bOK)
        {
            Console.WriteLine("Set BufferCount to " + uiBufferCount);
            if ((iRetValue = CLLTI.SetBufferCount(hLLT, uiBufferCount)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetBufferCount", iRetValue);
                bOK = false;
            }
        }

        if (bOK)
        {
            Console.WriteLine("Set MainReflection to " + uiMainReflection);
            if ((iRetValue = CLLTI.SetMainReflection(hLLT, uiMainReflection)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetMainReflection", iRetValue);
                bOK = false;
            }
        }               

        if (bOK)
        {
            Console.WriteLine("Set Packetsize to " + uiPacketSize);
            if ((iRetValue = CLLTI.SetPacketSize(hLLT, uiPacketSize)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetPacketSize", iRetValue);
                bOK = false;
            }
        }

        if (bOK)
        {
            Console.WriteLine("Set Profile config to PROFILE");
            if ((iRetValue = CLLTI.SetProfileConfig(hLLT, CLLTI.TProfileConfig.VIDEO_IMAGE)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetProfileConfig", iRetValue);
                bOK = false;
            }
        }

        if (bOK)
        {
            Console.WriteLine("Set trigger to internal");
            if ((iRetValue = CLLTI.SetFeature(hLLT, CLLTI.FEATURE_FUNCTION_TRIGGER, CLLTI.TRIG_INTERNAL)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetFeature(FEATURE_FUNCTION_TRIGGER)", iRetValue);
                bOK = false;
            }
        }

        if (bOK)
        {
            Console.WriteLine("Set exposure time to " + uiExposureTime);
            if ((iRetValue = CLLTI.SetFeature(hLLT, CLLTI.FEATURE_FUNCTION_EXPOSURE_TIME, uiExposureTime)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetFeature(FEATURE_FUNCTION_EXPOSURE_TIME)", iRetValue);
                bOK = false;
            }
        }

        if (bOK)
        {
            Console.WriteLine("Set idle time to " + uiIdleTime);
            if ((iRetValue = CLLTI.SetFeature(hLLT, CLLTI.FEATURE_FUNCTION_IDLE_TIME, uiIdleTime)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during SetFeature(FEATURE_FUNCTION_IDLE_TIME)", iRetValue);
                bOK = false;
            }
        }        

        // Main tasks in this example
        if(bOK)
        {
          Console.WriteLine("\n----- Poll video image from scanCONTROL -----\n");

          Video_Mode();
        }     

        if(bConnected)
        {
           Console.WriteLine("\n----- Disconnect from scanCONTROL -----\n");

          // Disconnect from the sensor
          Console.WriteLine("Disconnect the scanCONTROL");
          if((iRetValue = CLLTI.Disconnect(hLLT)) < CLLTI.GENERAL_FUNCTION_OK)
          {
            OnError("Error during Disconnect", iRetValue);
          }
        }

        if (bConnected)
        {
            // Free ressources
            Console.WriteLine("Delete the scanCONTROL instance");
            if ((iRetValue = CLLTI.DelDevice(hLLT)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                OnError("Error during Delete", iRetValue);
            }
        }
      }

      //Wait for a keyboard hit
      while(true)
      {
        cki = Console.ReadKey();
        if (cki.KeyChar != 0)
        {
          break;
        }
      }
    }

    /*
     *  Set the scanner to transmit the raw video image of the scanner matrix and saves it as Bitmap
     *  The raw image is useful to judge the exposure time and reflection behaviour
     */ 
    static void Video_Mode()
    {
      int iRetValue = 0;
      uint uiLostProfiles = 0;
      uint uiVideoWidth = 0, uiVideoHeight = 0;

      // Set the file name of image
      StringBuilder sbVideoFileName = new StringBuilder("image.bmp");
   
      CLLTI.TTransferVideoType tvtVideoType = CLLTI.TTransferVideoType.VIDEO_MODE_1;
      // If scanCONTROL 30xx series is used, a downsampled video image is polled to save bandwidth
      if (tscanCONTROLType >= CLLTI.TScannerType.scanCONTROL30xx_25 && tscanCONTROLType <= CLLTI.TScannerType.scanCONTROL30xx_xxx) {
          tvtVideoType = CLLTI.TTransferVideoType.VIDEO_MODE_0;
      }

      // Start continous transmission in Video Mode setting
      Console.WriteLine("Enable the video stream");
      if ((iRetValue = CLLTI.TransferVideoStream(hLLT, tvtVideoType, 1, ref uiVideoWidth, ref uiVideoHeight)) < CLLTI.GENERAL_FUNCTION_OK)
      {
          OnError("Error during TransferProfiles", iRetValue);
          return;
      }

      // Sleep for a while to warm up the transfer
      System.Threading.Thread.Sleep(1000);

      // Allocate video buffer according to detected video size
      byte[] abyVideoBuffer = new byte[uiVideoHeight * uiVideoWidth];

      // Setup saving the video image with filename and bitmap
      Console.WriteLine("Setup saving video image");
      if ((iRetValue = CLLTI.SaveProfiles(hLLT, sbVideoFileName, CLLTI.TFileType.BMP)) < CLLTI.GENERAL_FUNCTION_OK)
      {
          OnError("Error during SaveProfiles", iRetValue);
          return;
      }  

      // Sleep for a while to warm up the transfer
      System.Threading.Thread.Sleep(1000);

      // Get the next available image and write it to video buffer
      Console.WriteLine("Get Video Image Data");
      if ((iRetValue = CLLTI.GetActualProfile(hLLT, abyVideoBuffer, abyVideoBuffer.GetLength(0), CLLTI.TProfileConfig.VIDEO_IMAGE, ref uiLostProfiles)) < CLLTI.GENERAL_FUNCTION_OK)
      {
          OnError("Error GetActualProfile", iRetValue);
          return;
      }

      // Stop continous profile transmission
      Console.WriteLine("Stop the video stream");
      if((iRetValue = CLLTI.TransferVideoStream(hLLT, CLLTI.TTransferVideoType.VIDEO_MODE_1, 0, ref uiVideoWidth, ref uiVideoHeight)) < CLLTI.GENERAL_FUNCTION_OK)
      {
        OnError("Error during TransferProfiles", iRetValue);
        return;
      }
    }

    // Display the error text
    static void OnError(string strErrorTxt, int iErrorValue)
    {
      byte[] acErrorString = new byte[200];

      Console.WriteLine(strErrorTxt);
      if(CLLTI.TranslateErrorValue(hLLT, iErrorValue, acErrorString, acErrorString.GetLength(0))
                                      >= CLLTI.GENERAL_FUNCTION_OK)
      Console.WriteLine(System.Text.Encoding.ASCII.GetString(acErrorString, 0, acErrorString.GetLength(0)));
    }
  }
}
