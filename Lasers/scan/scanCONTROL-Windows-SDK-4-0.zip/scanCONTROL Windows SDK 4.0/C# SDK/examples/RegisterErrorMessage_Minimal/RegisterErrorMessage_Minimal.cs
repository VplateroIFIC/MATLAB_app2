﻿/*
 * scanCONTROL C# SDK - C# wrapper for LLT.dll
 *
 * MIT License
 *
 * Copyright © 2017-2018 Micro-Epsilon Messtechnik GmbH & Co. KG
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

using System;
using System.Windows.Forms;

namespace MEScanControl
{
    class CScanCONTROLSample
    {
        /* Global variables */
        public const int MAX_INTERFACE_COUNT = 5;
        public bool bConnected = false;
        static public uint hLLT = 0;

        [STAThread]
        static void Main(string[] args)
        {
            // Standard Windows Application calls
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        /*
         * Connect scanCONTROL and set some parameters
         */ 
        public void scanCONTROL_Sample()
        {
            uint[] auiInterfaces = new uint[MAX_INTERFACE_COUNT];

            int iInterfaceCount = 0;
            int iRetValue = 0;    

            hLLT = 0;

            //Create a Ethernet Device -> returns handle to LLT device
            hLLT = CLLTI.CreateLLTDevice(CLLTI.TInterfaceType.INTF_TYPE_ETHERNET);
            if (hLLT == 0)
                return;

            //Gets the available interfaces from the scanCONTROL-device
            iInterfaceCount = CLLTI.GetDeviceInterfacesFast(hLLT, auiInterfaces, auiInterfaces.GetLength(0));
            if (iInterfaceCount <= 0)
                return;

            // Set the first IP address detected by GetDeviceInterfacesFast to handle
            if ((iRetValue = CLLTI.SetDeviceInterface(hLLT, auiInterfaces[0], 0))
                < CLLTI.GENERAL_FUNCTION_OK)
            {
                return;
            }

            // Connect to sensor with the device interface set before
            if ((iRetValue = CLLTI.Connect(hLLT)) < CLLTI.GENERAL_FUNCTION_OK)
            {
                return;
            }
            else
                bConnected = true;
        }
        
        /*
         * Disconnect scanCONTROL and free ressources 
         */ 
        public void Disconnect()
        {
            int iRetValue = 0;
            if (bConnected)
            {
                // Disconnect from the sensor
                Console.WriteLine("Disconnect the scanCONTROL");
                if ((iRetValue = CLLTI.Disconnect(hLLT)) < CLLTI.GENERAL_FUNCTION_OK)
                {
                    return;
                }
            }

            if (bConnected)
            {
                // Free ressources
                Console.WriteLine("Delete the scanCONTROL instance");
                if ((iRetValue = CLLTI.DelDevice(hLLT)) < CLLTI.GENERAL_FUNCTION_OK)
                {
                    return;
                }
            }
        } 
    }
}
